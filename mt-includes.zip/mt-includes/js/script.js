$(document).ready(function () {
    $.getJSON('https://api.covid19india.org/data.json', function (data) {

        /*
        *-----------------Time Series Data------------------
        */
       let time_confirmed = [];
       let time_recovered = [];
       let time_deaths = [];
       let time_dates = [];

       $.each(data.cases_time_series, function (id, obj) {
           time_confirmed.push(obj.totalconfirmed);
           time_deaths.push(obj.totaldeceased);
           time_recovered.push(obj.totalrecovered);
           time_dates.push(obj.date)
       });

       let myChart = document.getElementById("dailyRec").getContext("2d");

       let chart = new Chart(myChart, {
           type: "line",
           data: {
               labels: time_dates.slice(-21, -1),
               datasets: [
                   {
                       label: "Confirmed",
                       data: time_confirmed.slice(-21, -1),
                       borderColor: "yellow"
                   },
                   {
                       label: "Recovered",
                       data: time_recovered.slice(-21, -1),
                       borderColor: "green"
                   },
                   {
                       label: "Deaths",
                       data: time_deaths.slice(-21, -1),
                       borderColor: "red"
                   }
               ]
           },
           options: {}
       });

    });
});

$(document).ready(function() {
    $.getJSON('https://api.covid19india.org/data.json', function(data){
        let states = [];
        let confirmed = [];
        let recovered = [];
        let deaths = [];

        $.each(data.statewise, function(id,obj) {
            states.push(obj.state);
            confirmed.push(obj.confirmed);
            recovered.push(obj.recovered);
            deaths.push(obj.deaths);
        });

        states.shift();
        let total_confirmed = confirmed.shift();
        let total_recovered = recovered.shift();
        let total_deaths = deaths.shift();
        let total_active = total_confirmed - total_recovered - total_deaths;

        $("#confirmed").append(total_confirmed);
        $("#active").append(total_active);
        $("#recovered").append(total_recovered);
        $("#deaths").append(total_deaths);

        let myChart = document.getElementById("stateWise").getContext("2d");

        let chart = new Chart(myChart, {
            type:"bar",
            data:{
                labels: states,
                datasets: [
                    {
                        label: "Confirmed",
                        data: confirmed,
                        backgroundColor: "orange"
                    }
                ]
            },
            options:{}
        });
    });
});